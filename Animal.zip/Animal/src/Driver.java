/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brads
 */
public class Driver {
    public static void main(String[] args) {
        Bird brd;
        Reptile rept;
        brd.print();
        rept.print();
    }
}
