/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brads
 */
public class Bird extends Animal{
    
    int colour;
    
    public String getColour() { 
        if(colour == 1)
        {
           return "grey"; 
        }
        else if(colour == 2)
        {
           return "white"; 
        }
        else
        {
           return "black"; 
        }
    }
    
    public void setColor(int colour) {
        colour = colour;
    }
  
    @Override
    public int getIDtag() {
        return IDtag;
    }

    public String getSpecies() {
        return species;
    }

    public void setIDtag(int IDtag) {
        this.IDtag = IDtag;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public Bird(int colour, int IDtag, String species) {
        super(IDtag, species);
        colour = colour;
    }
    
    void print()
    {
        System.out.println("Bird ID:" + IDtag + "Species:" + species + "Colour" + colour); 
    } 
}
