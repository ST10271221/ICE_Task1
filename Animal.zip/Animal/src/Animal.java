/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brads
 */
public class Animal {
    
    public int IDtag; //Variables 
    public String species;

    public int getIDtag() {  //Creating Get Values 
        return IDtag;
    }

    public String getSpecies() {
        return species;
    }

    public void setIDtag(int IDtag) { // Declaring Set Values
        IDtag = IDtag;
    }

    public void setSpecies(String species) {
        species = species;
    }

    public Animal(int IDtag, String species) { // Created Constructor.
        IDtag = IDtag;
        species = species;
    }
}
