/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author brads
 */
public class Reptile extends Animal {
    
    double bloodTemp;

    public Reptile(int IDtag, String species double bloodTemp) {
        super(IDtag, species);
        bloodTemp = bloodTemp;
    }

    public double getBloodTemp() {
        return bloodTemp;
    }

    @Override
    public int getIDtag() {
        return IDtag;
    }
    
    @Override
    public String getSpecies() {
        return species;
    }

    public void setBloodTemp(double bloodTemp) {
        bloodTemp = bloodTemp;
    }

    @Override
    public void setIDtag(int IDtag) {
        IDtag = IDtag;
    }

    @Override
    public void setSpecies(String species) {
        species = species;
    }
    
    void print() 
    {
        System.out.println("Reptile ID:" + IDtag + "Species:" + species + "Temperature:" + bloodTemp);
    }
}
